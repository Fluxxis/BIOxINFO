# Bio Cover — Next.js

Это Next.js обёртка вокруг твоего статического проекта.

## Где лежит твой сайт
`/public/site/*`

Открывается на главной странице через iframe: `/site/index.html`.

## Запуск локально
```bash
npm i
npm run dev
```

## Деплой на Vercel
Просто импортируй репозиторий/архив — Vercel сам распознает Next.js.
