window.SITE_CONFIG = {
  name: "kosyak🚬",
  tagline: "w1rooow",

  // Аудио: положи в /public одну из версий:
  // song.mp3 / song.ogg / song.wav / song.m4a
  // Сайт сам выберет первую найденную.
  songBaseName: "public/song",
  songExtensions: ["mp3", "ogg", "wav", "m4a"],

  trackTitle: "nuts",
  openLink: "https://open.spotify.com/",

  links: {
    discord: "https://discord.com/channels/1459594772279988398/1459594772887900363",
    roblox: "https://www.roblox.com/users/4583484745/profile?friendshipSourceType=PlayerSearch",
    telegram: "https://t.me/tonhind",
    spotify: "https://open.spotify.com/playlist/4xqWidWkyCHpOJRkf791qq?si=KY25VsLETDek4jGYsFHvyg&pi=vi9usY9oTBCpC",
    tiktok: "https://www.tiktok.com/@heylon719?_r=1&_t=ZG-93ROZ3lTeL2"
  }
};
